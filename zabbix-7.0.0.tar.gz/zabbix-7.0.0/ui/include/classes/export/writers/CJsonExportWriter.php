<?php
/*
** Copyright (C) 2001-2024 Zabbix SIA
**
** This program is free software: you can redistribute it and/or modify it under the terms of
** the GNU Affero General Public License as published by the Free Software Foundation, version 3.
**
** This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
** without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
** See the GNU Affero General Public License for more details.
**
** You should have received a copy of the GNU Affero General Public License along with this program.
** If not, see <https://www.gnu.org/licenses/>.
**/


/**
 * Class for converting array with export data to JSON format.
 */
class CJsonExportWriter extends CExportWriter {

	/**
	 * Convert array with export data to JSON format.
	 *
	 * @param array $array
	 *
	 * @return string
	 */
	public function write(array $array) {
		$options = JSON_UNESCAPED_SLASHES;

		if ($this->formatOutput) {
			$options |= JSON_PRETTY_PRINT;
		}

		return json_encode($array, $options);
	}
}
